<?php
$redirect_url = 'webpage\dashboard.php';

header('Location: ' . $redirect_url);
exit();
?>